let leaderboard = [];
let previousScores = [];
let recentScore = null;
let currentUser = null; // Track the current logged in user
let activityLog = {}; // Track user activity log
let workoutTimestamps = {}; // Store timestamps for users' workouts

// Login functionality
document.getElementById("login-button").addEventListener("click", function() {
    const loginPasswordInput = document.getElementById("login-password-input").value;
    const errorMessage = document.getElementById("login-error-message");

    if (loginPasswordInput === "6902") {
        errorMessage.textContent = "";
        document.getElementById("password-panel").classList.add("hidden");
        document.getElementById("menu-panel").classList.remove("hidden");
    } else {
        errorMessage.textContent = "Incorrect password. Please try again.";
    }
});

// Menu navigation
document.getElementById("signup-button").addEventListener("click", function() {
    document.getElementById("menu-panel").classList.add("hidden");
    document.getElementById("signup-panel").classList.remove("hidden");
});

document.getElementById("existing-login-button").addEventListener("click", function() {
    document.getElementById("menu-panel").classList.add("hidden");
    document.getElementById("login-panel").classList.remove("hidden");
});

// Handle Sign-Up
document.getElementById("submit-signup-button").addEventListener("click", function() {
    const nameInput = document.getElementById("name-input").value;
    const passwordInput = document.getElementById("password-input").value;
    const confirmPasswordInput = document.getElementById("confirm-password-input").value;

    const errorMessage = document.getElementById("signup-error-message");

    if (nameInput && passwordInput === confirmPasswordInput && passwordInput !== "") {
        if (leaderboard.find(user => user.name === nameInput)) {
            errorMessage.textContent = "This name is already taken. Please choose another.";
            return;
        }
        leaderboard.push({ name: nameInput, points: 0, password: passwordInput });
        activityLog[nameInput] = []; // Initialize activity log for new user
        errorMessage.textContent = "";
        document.getElementById("signup-panel").classList.add("hidden");
        document.getElementById("main-panel").classList.remove("hidden");
        currentUser = leaderboard[leaderboard.length - 1]; // Set current user to last added
        updateLeaderboard();
        document.getElementById("name-input").value = ""; // Clear input field
        document.getElementById("password-input").value = ""; // Clear password field
        document.getElementById("confirm-password-input").value = ""; // Clear confirm password field
    } else {
        errorMessage.textContent = "Make sure your passwords match and are not empty.";
    }
});

// Handle Login
document.getElementById("submit-login-button").addEventListener("click", function() {
    const nameInput = document.getElementById("login-name-input").value;
    const passwordInput = document.getElementById("login-user-password-input").value;

    const errorMessage = document.getElementById("user-login-error-message");
    const user = leaderboard.find(user => user.name === nameInput && user.password === passwordInput);

    if (user) {
        errorMessage.textContent = "";
        currentUser = user; // Set current user
        document.getElementById("login-panel").classList.add("hidden");
        document.getElementById("main-panel").classList.remove("hidden");
        updateLeaderboard();
    } else {
        errorMessage.textContent = "Incorrect name or password. Please try again.";
    }
});

// Handle Point Menu Toggle
document.getElementById("add-points-button").addEventListener("click", function() {
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("points-menu").classList.remove("hidden");
});

// Confirm Points and Activity
document.getElementById("confirm-points-button").addEventListener("click", function() {
    const pointsInput = parseInt(document.getElementById("points-input").value);
    const activityInput = document.getElementById("activity-select").value;

    if (!isNaN(pointsInput) && activityInput) {
        recentScore = { user: currentUser.name, points: pointsInput, activity: activityInput, timestamp: new Date() }; // Store recent score for undo/redo
        previousScores.push(currentUser.points); // Store previous score
        currentUser.points += pointsInput; // Update the points
        activityLog[currentUser.name].push({ activity: activityInput, points: pointsInput, timestamp: recentScore.timestamp }); // Log activity for the user
        
        // Store timestamp for displaying workout details
        workoutTimestamps[currentUser.name] = recentScore.timestamp;

        updateLeaderboard();
        document.getElementById("points-input").value = ""; // Clear input field
        document.getElementById("activity-select").value = ""; // Clear activity field
    }
});

// Undo/Redo functionality in Points Menu
document.getElementById("undo-button").addEventListener("click", function() {
    if (recentScore) {
        const respectiveUser = leaderboard.find(u => u.name === recentScore.user);
        respectiveUser.points = previousScores.pop() || 0; // Restore the previous score
        recentScore = null; // Reset recent score
        updateLeaderboard();
    }
});

document.getElementById("redo-button").addEventListener("click", function() {
    if (recentScore) {
        const respectiveUser = leaderboard.find(u => u.name === recentScore.user);
        respectiveUser.points += recentScore.points; // Reapply the most recent score
        previousScores.push(respectiveUser.points - recentScore.points); // Save the state before redo
        updateLeaderboard();
    }
});

// Handle Rules Page
document.getElementById("rules-button").addEventListener("click", function() {
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("rules-panel").classList.remove("hidden");
});

// Handle Back to Points Page
document.getElementById("back-button").addEventListener("click", function() {
    document.getElementById("rules-panel").classList.add("hidden");
    document.getElementById("main-panel").classList.remove("hidden");
});

// Handle back to home functionality
document.getElementById("home-button").addEventListener("click", function() {
    // Hide all panels and show the password panel
    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("signup-panel").classList.add("hidden");
    document.getElementById("login-panel").classList.add("hidden");
    document.getElementById("menu-panel").classList.add("hidden");
    document.getElementById("password-panel").classList.remove("hidden");
});

// Add home button functionality for signup and login
document.getElementById("signup-home-button").addEventListener("click", function() {
    document.getElementById("signup-panel").classList.add("hidden");
    document.getElementById("menu-panel").classList.remove("hidden");
});

document.getElementById("login-home-button").addEventListener("click", function() {
    document.getElementById("login-panel").classList.add("hidden");
    document.getElementById("menu-panel").classList.remove("hidden");
});

// Add home button functionality for points menu
document.getElementById("points-menu-home-button").addEventListener("click", function() {
    document.getElementById("points-menu").classList.add("hidden");
    document.getElementById("main-panel").classList.remove("hidden");
});

// Handle User Detail View
document.getElementById("leaderboard-list").addEventListener("click", function(e) {
    const userName = e.target.textContent.split(":")[0].trim(); // Get user name from the list
    const userActivities = activityLog[userName] || [];
    document.getElementById("user-detail-name").textContent = userName;

    const userDetailList = document.getElementById("user-detail-list");
    userDetailList.innerHTML = ""; // Clear existing list

    userActivities.forEach(activity => {
        const listItem = document.createElement("li");
        listItem.textContent = `${activity.activity}: ${activity.points} Points`;
        
        // Add time since last workout for each activity
        const timeDiff = Math.floor((Date.now() - new Date(activity.timestamp).getTime()) / 1000);
        const timeString = timeDiff > 0 ? `${timeDiff} seconds ago` : "Just now";
        listItem.textContent += ` (${timeString})`; // Append time to the activity
        
        userDetailList.appendChild(listItem);
    });

    document.getElementById("main-panel").classList.add("hidden");
    document.getElementById("user-detail-panel").classList.remove("hidden");
});

// Add back to home functionality for user detail panel
document.getElementById("user-detail-home-button").addEventListener("click", function() {
    document.getElementById("user-detail-panel").classList.add("hidden");
    document.getElementById("main-panel").classList.remove("hidden");
});

// Update Leaderboard
function updateLeaderboard() {
    leaderboard.sort((a, b) => b.points - a.points); // Sort leaderboard based on points
    const leaderboardList = document.getElementById("leaderboard-list");
    leaderboardList.innerHTML = ""; // Clear existing list

    leaderboard.forEach((entry, index) => {
        const listItem = document.createElement("li");
        const color = (index === 0) ? "gold" : (index === 1) ? "silver" : (index === 2) ? "lightgoldenrodyellow" : "white";
        listItem.textContent = `${entry.name}: ${entry.points} Points`;
        listItem.style.color = color; // Color based on rank
        leaderboardList.appendChild(listItem);
    });
}